export interface Coin {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change24h: number;
  isMeme: boolean;
  icon: string;
  marketCap: number;
  volume24h: number;
  priceHistory: number[];
}

export interface Portfolio {
  coins: {
    coinId: string;
    amount: number;
    averageBuyPrice: number;
  }[];
  balance: number;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  reward: number;
  completed: boolean;
  requirements: {
    type: 'trade' | 'learn' | 'hold';
    target: number;
    progress: number;
  };
}

export interface LessonModule {
  id: string;
  title: string;
  content: string;
  completed: boolean;
  quiz: {
    question: string;
    options: string[];
    correctAnswer: number;
  }[];
}

export interface Settings {
  volume: number;
  language: string;
  version: string;
}

export interface MoneyEvent {
  amount: number;
  reason: string;
  animation: string;
}