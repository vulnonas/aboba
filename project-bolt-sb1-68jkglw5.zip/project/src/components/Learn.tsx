import React, { useState } from 'react';
import { useGameStore } from '../store/gameStore';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';

export const Learn: React.FC = () => {
  const { t } = useTranslation();
  const { lessons, completeLessonModule } = useGameStore();
  const [selectedLesson, setSelectedLesson] = useState<string | null>(null);
  const [wrongAnswer, setWrongAnswer] = useState<number | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleLessonClick = (lessonId: string) => {
    setSelectedLesson(selectedLesson === lessonId ? null : lessonId);
  };

  const handleAnswerClick = (lessonId: string, questionIndex: number, selectedAnswer: number, correctAnswer: number) => {
    if (selectedAnswer === correctAnswer) {
      setShowSuccess(true);
      completeLessonModule(lessonId);
      setTimeout(() => {
        setShowSuccess(false);
        setSelectedLesson(null); // Close the module after success
      }, 3000);
    } else {
      setWrongAnswer(selectedAnswer);
      setTimeout(() => {
        setWrongAnswer(null);
      }, 1000);
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">{t('learn.title')}</h2>
      <div className="space-y-4">
        {lessons.map(lesson => (
          <div 
            key={lesson.id} 
            className={`bg-white p-4 rounded-lg shadow transition-all duration-300 cursor-pointer ${
              selectedLesson === lesson.id ? 'ring-2 ring-blue-500' : ''
            }`}
            onClick={() => handleLessonClick(lesson.id)}
          >
            <div className="flex justify-between items-center">
              <h3 className="font-semibold text-lg">{t(`learn.lessons.${lesson.id}.title`)}</h3>
              {lesson.completed && (
                <span className="text-green-600">✓ {t('learn.completed')}</span>
              )}
            </div>
            
            <AnimatePresence>
              {selectedLesson === lesson.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="mt-4 overflow-hidden"
                >
                  <p className="text-gray-600 mb-4">{t(`learn.lessons.${lesson.id}.content`)}</p>
                  <div>
                    <h4 className="font-semibold mb-2">{t('learn.quiz')}</h4>
                    {lesson.quiz.map((q, index) => (
                      <div key={index} className="mb-4">
                        <p className="font-medium mb-2">{t(`learn.lessons.${lesson.id}.quiz.${index}.question`)}</p>
                        <div className="space-y-2">
                          {q.options.map((option, optIndex) => (
                            <motion.button
                              key={optIndex}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleAnswerClick(lesson.id, index, optIndex, q.correctAnswer);
                              }}
                              className={`w-full text-left p-2 rounded border transition-colors ${
                                wrongAnswer === optIndex ? 'bg-red-100 border-red-300' : 'border-gray-300 hover:bg-gray-50'
                              }`}
                              animate={wrongAnswer === optIndex ? {
                                x: [-10, 10, -10, 10, 0],
                                transition: { duration: 0.5 }
                              } : {}}
                            >
                              {t(`learn.lessons.${lesson.id}.quiz.${index}.options.${optIndex}`)}
                            </motion.button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
      
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0 }}
            className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          >
            <div className="text-6xl">🎉</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};