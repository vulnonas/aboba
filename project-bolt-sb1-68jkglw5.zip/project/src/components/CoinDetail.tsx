import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../store/gameStore';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface CoinDetailProps {
  coin: any;
  onClose: () => void;
}

const timeRanges = [
  { label: '1H', hours: 1 },
  { label: '24H', hours: 24 },
  { label: '3D', hours: 72 },
  { label: '1Y', hours: 8760 }
];

function formatLargeNumber(num: number): string {
  if (num >= 1e9) {
    return `$${(num / 1e9).toFixed(2)}B`;
  } else if (num >= 1e6) {
    return `$${(num / 1e6).toFixed(2)}M`;
  }
  return `$${num.toLocaleString()}`;
}

export const CoinDetail: React.FC<CoinDetailProps> = ({ coin, onClose }) => {
  const { t } = useTranslation();
  const { coins } = useGameStore();
  const [selectedRange, setSelectedRange] = useState(24);
  const [comparisonCoin, setComparisonCoin] = useState<string | null>(null);

  const chartData = {
    labels: Array(selectedRange).fill(''),
    datasets: [
      {
        label: coin.name,
        data: [...coin.priceHistory].slice(-selectedRange).reverse(),
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1,
        fill: false
      },
      ...(comparisonCoin ? [{
        label: coins.find(c => c.id === comparisonCoin)?.name || '',
        data: [...(coins.find(c => c.id === comparisonCoin)?.priceHistory || [])].slice(-selectedRange).reverse(),
        borderColor: 'rgb(255, 99, 132)',
        tension: 0.1,
        fill: false
      }] : [])
    ]
  };

  const chartOptions = {
    responsive: true,
    scales: {
      x: {
        display: false
      },
      y: {
        beginAtZero: false,
        min: 0.000001
      }
    },
    plugins: {
      legend: {
        display: true,
        position: 'top' as const
      }
    },
    interaction: {
      intersect: false,
      mode: 'index' as const
    }
  };

  const otherCoins = coins.filter(c => c.id !== coin.id);

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-lg p-6 w-full max-w-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex flex-col items-center mb-6">
          <h2 className="text-2xl font-bold mb-4">{coin.name}</h2>
          
          <div className="flex items-center space-x-4 mb-4">
            <div className="flex space-x-2">
              {timeRanges.map(range => (
                <button
                  key={range.hours}
                  onClick={() => setSelectedRange(range.hours)}
                  className={`px-3 py-1 rounded ${
                    selectedRange === range.hours
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  {range.label}
                </button>
              ))}
            </div>
          </div>

          <div className="w-full mb-4">
            <div className="relative">
              <label htmlFor="comparison" className="block text-lg font-semibold mb-2 text-gray-700">
                {t('market.compareWith')}
              </label>
              <select
                id="comparison"
                value={comparisonCoin || ''}
                onChange={(e) => setComparisonCoin(e.target.value || null)}
                className="w-full p-2 border border-gray-300 rounded-lg bg-white text-gray-900 shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              >
                <option value="">{t('market.selectCrypto')}</option>
                {otherCoins.map(c => (
                  <option key={c.id} value={c.id} className="flex items-center">
                    {c.icon} {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <Line data={chartData} options={chartOptions} />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-100 p-4 rounded">
            <h3 className="text-gray-600">{t('market.marketCap')}</h3>
            <p className="text-xl font-bold text-gray-900">
              {formatLargeNumber(coin.marketCap || coin.price * 1000000)}
            </p>
          </div>
          <div className="bg-gray-100 p-4 rounded">
            <h3 className="text-gray-600">{t('market.volume')}</h3>
            <p className="text-xl font-bold text-gray-900">
              {formatLargeNumber(coin.volume24h || coin.price * 100000)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};