import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '../store/gameStore';
import { CoinDetail } from './CoinDetail';

interface MarketProps {
  type: 'crypto' | 'meme';
}

export const Market: React.FC<MarketProps> = ({ type }) => {
  const { t } = useTranslation();
  const { coins, buyCoin, portfolio } = useGameStore();
  const [selectedCoin, setSelectedCoin] = useState<string | null>(null);
  const [buyAnimation, setBuyAnimation] = useState<string | null>(null);
  const [buyAmount, setBuyAmount] = useState<{ [key: string]: number }>({});

  const filteredCoins = coins.filter(coin => coin.isMeme === (type === 'meme'));
  const backgroundClass = type === 'crypto' 
    ? 'bg-gradient-to-b from-blue-900 to-blue-800' 
    : 'bg-gradient-to-b from-purple-900 to-purple-800';

  const handleBuy = (coinId: string, amount: number) => {
    buyCoin(coinId, amount);
    setBuyAnimation(coinId);
    setTimeout(() => setBuyAnimation(null), 500);
  };

  const getOwnedAmount = (coinId: string) => {
    const position = portfolio.coins.find(c => c.coinId === coinId);
    return position?.amount || 0;
  };

  return (
    <div className={`p-4 min-h-screen ${backgroundClass} text-white pb-20`}>
      <div className="bg-white bg-opacity-20 p-4 rounded-lg shadow mb-4 backdrop-blur-sm">
        <p className="text-gray-200">{t('market.availableBalance')}</p>
        <p className="text-2xl font-bold">${portfolio.balance.toFixed(2)}</p>
      </div>

      <h2 className="text-2xl font-bold mb-4">
        {type === 'crypto' ? t('market.cryptoMarket') : t('market.memeMarket')}
      </h2>
      
      <div className="space-y-4">
        {filteredCoins.map(coin => (
          <motion.div
            key={coin.id}
            className="bg-white bg-opacity-10 p-4 rounded-lg shadow backdrop-blur-sm"
            animate={buyAnimation === coin.id ? { scale: [1, 1.02, 1] } : {}}
          >
            <div 
              className="flex justify-between items-center cursor-pointer"
              onClick={() => setSelectedCoin(coin.id)}
            >
              <div className="flex items-center">
                <span className="text-2xl mr-2">{coin.icon}</span>
                <div>
                  <h3 className="font-semibold">{coin.name}</h3>
                  <p className="text-sm text-gray-300">
                    {coin.symbol} • {t('market.owned')}: {getOwnedAmount(coin.id)}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold">${coin.price.toFixed(2)}</p>
                <p className={`text-sm ${coin.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {coin.change24h >= 0 ? '+' : ''}{coin.change24h.toFixed(2)}%
                </p>
              </div>
            </div>
            <div className="mt-4 flex space-x-2">
              <input
                type="number"
                min="1"
                value={buyAmount[coin.id] || 1}
                onChange={(e) => setBuyAmount({
                  ...buyAmount,
                  [coin.id]: Math.max(1, parseInt(e.target.value) || 1)
                })}
                className="w-24 px-2 py-1 border rounded text-gray-900"
                onClick={e => e.stopPropagation()}
              />
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleBuy(coin.id, buyAmount[coin.id] || 1);
                }}
                className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={coin.price * (buyAmount[coin.id] || 1) > portfolio.balance}
              >
                {t('market.buy')}
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedCoin && (
          <CoinDetail
            coin={coins.find(c => c.id === selectedCoin)}
            onClose={() => setSelectedCoin(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};