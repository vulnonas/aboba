import React from 'react';
import { useTranslation } from 'react-i18next';
import { 
  CurrencyDollarIcon, 
  ChartBarIcon, 
  AcademicCapIcon, 
  GiftIcon, 
  SparklesIcon,
  Cog6ToothIcon 
} from '@heroicons/react/24/outline';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const { t } = useTranslation();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
      <div className="flex justify-around items-center h-16">
        <button
          onClick={() => onTabChange('crypto')}
          className={`flex flex-col items-center ${activeTab === 'crypto' ? 'text-blue-600' : 'text-gray-600'}`}
        >
          <CurrencyDollarIcon className="h-6 w-6" />
          <span className="text-xs">{t('navigation.crypto')}</span>
        </button>

        <button
          onClick={() => onTabChange('meme')}
          className={`flex flex-col items-center ${activeTab === 'meme' ? 'text-blue-600' : 'text-gray-600'}`}
        >
          <SparklesIcon className="h-6 w-6" />
          <span className="text-xs">{t('navigation.meme')}</span>
        </button>

        <button
          onClick={() => onTabChange('portfolio')}
          className={`flex flex-col items-center ${activeTab === 'portfolio' ? 'text-blue-600' : 'text-gray-600'}`}
        >
          <ChartBarIcon className="h-6 w-6" />
          <span className="text-xs">{t('navigation.portfolio')}</span>
        </button>

        <button
          onClick={() => onTabChange('learn')}
          className={`flex flex-col items-center ${activeTab === 'learn' ? 'text-blue-600' : 'text-gray-600'}`}
        >
          <AcademicCapIcon className="h-6 w-6" />
          <span className="text-xs">{t('navigation.learn')}</span>
        </button>

        <button
          onClick={() => onTabChange('quests')}
          className={`flex flex-col items-center ${activeTab === 'quests' ? 'text-blue-600' : 'text-gray-600'}`}
        >
          <GiftIcon className="h-6 w-6" />
          <span className="text-xs">{t('navigation.quests')}</span>
        </button>

        <button
          onClick={() => onTabChange('settings')}
          className={`flex flex-col items-center ${activeTab === 'settings' ? 'text-blue-600' : 'text-gray-600'}`}
        >
          <Cog6ToothIcon className="h-6 w-6" />
          <span className="text-xs">{t('navigation.settings')}</span>
        </button>
      </div>
    </div>
  );
};