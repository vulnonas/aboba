import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { MoneyEvent as MoneyEventType } from '../types';

interface MoneyEventProps {
  event: MoneyEventType;
  onClose: () => void;
}

const animations = {
  bounce: {
    initial: { scale: 0, y: 50 },
    animate: { scale: 1, y: 0, transition: { type: "spring", stiffness: 300 } },
    exit: { scale: 0, y: 50 }
  },
  slide: {
    initial: { x: -300, opacity: 0 },
    animate: { x: 0, opacity: 1 },
    exit: { x: 300, opacity: 0 }
  },
  rotate: {
    initial: { rotate: -180, opacity: 0 },
    animate: { rotate: 0, opacity: 1 },
    exit: { rotate: 180, opacity: 0 }
  },
  fade: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 }
  },
  scale: {
    initial: { scale: 0 },
    animate: { scale: 1 },
    exit: { scale: 0 }
  }
};

export const MoneyEvent: React.FC<MoneyEventProps> = ({ event, onClose }) => {
  const { t } = useTranslation();
  const animation = animations[event.animation as keyof typeof animations] || animations.fade;

  return (
    <AnimatePresence>
      <motion.div
        {...animation}
        className="fixed bottom-20 left-1/2 transform -translate-x-1/2 z-50"
      >
        <div className="bg-green-500 text-white rounded-lg shadow-lg p-6 max-w-md mx-auto">
          <h3 className="text-xl font-bold mb-2">💰 {t('events.moneyEvent')}</h3>
          <p className="text-lg mb-2">{event.reason}</p>
          <p className="text-2xl font-bold">+${event.amount.toFixed(2)}</p>
          <button
            onClick={onClose}
            className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
          >
            {t('events.close')}
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};