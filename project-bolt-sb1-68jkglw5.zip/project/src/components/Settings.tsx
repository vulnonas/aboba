import React from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../store/gameStore';
import { motion } from 'framer-motion';

export const Settings: React.FC = () => {
  const { t, i18n } = useTranslation();
  const { settings, updateSettings } = useGameStore();

  const handleLanguageChange = (lang: string) => {
    i18n.changeLanguage(lang);
    updateSettings({ language: lang });
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="p-4 bg-gradient-to-b from-gray-800 to-gray-900 min-h-screen pb-20"
    >
      <h2 className="text-2xl font-bold mb-6 text-white">{t('settings.title')}</h2>
      
      <div className="space-y-6">
        <div className="bg-gray-700 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-3 text-white">{t('settings.language')}</h3>
          <div className="flex space-x-4">
            <button
              onClick={() => handleLanguageChange('en')}
              className={`px-4 py-2 rounded ${
                settings.language === 'en' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-600 text-gray-300'
              }`}
            >
              English
            </button>
            <button
              onClick={() => handleLanguageChange('ru')}
              className={`px-4 py-2 rounded ${
                settings.language === 'ru' 
                  ? 'bg-red-600 text-white' 
                  : 'bg-gray-600 text-gray-300'
              }`}
            >
              Русский
            </button>
          </div>
        </div>

        <div className="bg-gray-700 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-3 text-white">{t('settings.volume')}</h3>
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={settings.volume}
            onChange={(e) => updateSettings({ volume: parseFloat(e.target.value) })}
            className="w-full"
          />
        </div>

        <div className="bg-gray-700 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-3 text-white">{t('settings.version')}</h3>
          <p className="text-gray-300">v{settings.version}</p>
        </div>
      </div>
    </motion.div>
  );
};