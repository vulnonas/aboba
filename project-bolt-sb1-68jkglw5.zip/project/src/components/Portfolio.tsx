import React, { useState } from 'react';
import { useGameStore } from '../store/gameStore';
import { useTranslation } from 'react-i18next';

export const Portfolio: React.FC = () => {
  const { t } = useTranslation();
  const { portfolio, coins, sellCoin, buyCoin } = useGameStore();
  const [buyAmount, setBuyAmount] = useState<{ [key: string]: number }>({});

  const calculateTotalValue = () => {
    return portfolio.coins.reduce((total, position) => {
      const coin = coins.find(c => c.id === position.coinId);
      return total + (coin?.price || 0) * position.amount;
    }, 0);
  };

  return (
    <div className="p-4 pb-20">
      <h2 className="text-2xl font-bold mb-4">{t('portfolio.title')}</h2>
      <div className="bg-white p-4 rounded-lg shadow mb-4">
        <p className="text-gray-600">{t('portfolio.availableBalance')}</p>
        <p className="text-2xl font-bold">${portfolio.balance.toFixed(2)}</p>
        <p className="text-gray-600 mt-2">{t('portfolio.totalValue')}</p>
        <p className="text-2xl font-bold">${calculateTotalValue().toFixed(2)}</p>
      </div>

      <div className="space-y-4">
        {portfolio.coins.map(position => {
          const coin = coins.find(c => c.id === position.coinId);
          if (!coin) return null;

          const currentValue = coin.price * position.amount;
          const profitLoss = currentValue - (position.averageBuyPrice * position.amount);
          const profitLossPercentage = (profitLoss / (position.averageBuyPrice * position.amount)) * 100;

          return (
            <div key={position.coinId} className="bg-white p-4 rounded-lg shadow">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <span className="text-2xl mr-2">{coin.icon}</span>
                  <div>
                    <h3 className="font-semibold">{coin.name}</h3>
                    <p className="text-sm text-gray-500">{position.amount} {coin.symbol}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold">${currentValue.toFixed(2)}</p>
                  <p className={`text-sm ${profitLoss >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {profitLoss >= 0 ? '+' : ''}{profitLossPercentage.toFixed(2)}%
                  </p>
                </div>
              </div>
              
              <div className="mt-4 flex space-x-2">
                <input
                  type="number"
                  min="1"
                  value={buyAmount[position.coinId] || 1}
                  onChange={(e) => setBuyAmount({
                    ...buyAmount,
                    [position.coinId]: Math.max(1, parseInt(e.target.value) || 1)
                  })}
                  className="w-24 px-2 py-1 border rounded"
                />
                <button
                  onClick={() => buyCoin(coin.id, buyAmount[position.coinId] || 1)}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={coin.price * (buyAmount[position.coinId] || 1) > portfolio.balance}
                >
                  {t('portfolio.buyMore')}
                </button>
                <button
                  onClick={() => sellCoin(coin.id, position.amount)}
                  className="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700"
                >
                  {t('portfolio.sellAll')}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};