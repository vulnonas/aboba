import React from 'react';
import { useGameStore } from '../store/gameStore';
import { useTranslation } from 'react-i18next';

export const Quests: React.FC = () => {
  const { t } = useTranslation();
  const { quests, completeQuest } = useGameStore();

  const getQuestDescription = (quest: any) => {
    switch (quest.id) {
      case 'first-trade':
        return t('quests.first-trade.description', 'Make your first cryptocurrency trade');
      case 'crypto-master':
        return t('quests.crypto-master.description', 'Complete all basic crypto lessons');
      case 'portfolio-diversity':
        return t('quests.portfolio-diversity.description', 'Own at least 3 different cryptocurrencies');
      default:
        return quest.description;
    }
  };

  const getQuestTitle = (quest: any) => {
    switch (quest.id) {
      case 'first-trade':
        return t('quests.first-trade.title', 'First Trade');
      case 'crypto-master':
        return t('quests.crypto-master.title', 'Crypto Master');
      case 'portfolio-diversity':
        return t('quests.portfolio-diversity.title', 'Portfolio Diversity');
      default:
        return quest.title;
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">{t('quests.title')}</h2>
      <div className="space-y-4">
        {quests.map(quest => (
          <div key={quest.id} className="bg-white p-4 rounded-lg shadow">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-semibold">{getQuestTitle(quest)}</h3>
                <p className="text-sm text-gray-600">{getQuestDescription(quest)}</p>
                <p className="text-sm text-green-600 mt-1">{t('quests.reward')}: ${quest.reward}</p>
              </div>
              {!quest.completed && (
                <button
                  onClick={() => completeQuest(quest.id)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  {t('quests.claim')}
                </button>
              )}
              {quest.completed && (
                <span className="text-green-600">✓ {t('quests.completed')}</span>
              )}
            </div>
            <div className="mt-4">
              <div className="bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 rounded-full h-2 transition-all duration-300"
                  style={{ width: `${(quest.requirements.progress / quest.requirements.target) * 100}%` }}
                />
              </div>
              <p className="text-sm text-gray-600 mt-1">
                {t('quests.progress')}: {quest.requirements.progress}/{quest.requirements.target}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};