import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';

interface MarketEventProps {
  event: {
    coin: string;
    change: number;
    reason: string;
  };
  onClose: () => void;
}

export const MarketEvent: React.FC<MarketEventProps> = ({ event, onClose }) => {
  const { t } = useTranslation();
  const isPositive = event.change > 0;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="fixed bottom-20 left-1/2 transform -translate-x-1/2 z-50"
      >
        <div className="bg-white rounded-lg shadow-lg p-6 max-w-md mx-auto">
          <h3 className="text-xl font-bold mb-2">{t('events.marketEvent')}</h3>
          <p className="text-gray-700 mb-2">{event.reason}</p>
          <p className={`text-lg font-semibold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {event.coin}: {isPositive ? '+' : ''}{event.change.toFixed(2)}%
          </p>
          <button
            onClick={onClose}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
          >
            {t('events.close')}
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};