import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { Market } from './components/Market';
import { Portfolio } from './components/Portfolio';
import { Learn } from './components/Learn';
import { Quests } from './components/Quests';
import { Settings } from './components/Settings';
import { MarketEvent } from './components/MarketEvent';
import { MoneyEvent } from './components/MoneyEvent';
import { useGameStore } from './store/gameStore';
import './i18n';

function App() {
  const [activeTab, setActiveTab] = useState('crypto');
  const { updateCoinPrices, currentEvent, clearEvent, moneyEvent, clearMoneyEvent } = useGameStore();

  useEffect(() => {
    updateCoinPrices();
    const interval = setInterval(updateCoinPrices, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, [updateCoinPrices]);

  const renderContent = () => {
    switch (activeTab) {
      case 'crypto':
        return <Market type="crypto" />;
      case 'meme':
        return <Market type="meme" />;
      case 'portfolio':
        return <Portfolio />;
      case 'learn':
        return <Learn />;
      case 'quests':
        return <Quests />;
      case 'settings':
        return <Settings />;
      default:
        return <Market type="crypto" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 pb-16">
      {renderContent()}
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      {currentEvent && <MarketEvent event={currentEvent} onClose={clearEvent} />}
      {moneyEvent && <MoneyEvent event={moneyEvent} onClose={clearMoneyEvent} />}
    </div>
  );
}

export default App;