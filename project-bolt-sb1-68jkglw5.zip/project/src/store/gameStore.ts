import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Coin, Portfolio, Quest, LessonModule, Settings } from '../types';

const marketEvents = {
  en: [
    { reason: "Trump announces new crypto regulations", min: -60, max: -30 },
    { reason: "China bans cryptocurrency trading", min: -65, max: -35 },
    { reason: "Elon Musk tweets about crypto", min: 35, max: 65 },
    { reason: "Major bank adopts cryptocurrency", min: 40, max: 70 },
    { reason: "SEC approves crypto ETF", min: 45, max: 65 },
    { reason: "EU announces crypto-friendly policies", min: 30, max: 60 },
    { reason: "Major hack in crypto exchange", min: -60, max: -35 },
    { reason: "Tech giant invests in Bitcoin", min: 35, max: 65 }
  ],
  ru: [
    { reason: "Трамп анонсирует новые правила для криптовалют", min: -60, max: -30 },
    { reason: "Китай запрещает торговлю криптовалютой", min: -65, max: -35 },
    { reason: "Илон Маск твитнул о крипте", min: 35, max: 65 },
    { reason: "Крупный банк внедряет криптовалюту", min: 40, max: 70 },
    { reason: "SEC одобряет крипто-ETF", min: 45, max: 65 },
    { reason: "ЕС объявляет о благоприятной политике для крипты", min: 30, max: 60 },
    { reason: "Крупный взлом на криптобирже", min: -60, max: -35 },
    { reason: "Технологический гигант инвестирует в Биткоин", min: 35, max: 65 }
  ]
};

const memeEvents = {
  en: [
    { reason: "New Bo Sinn meme goes viral", min: -60, max: 60 },
    { reason: "Doge meme reaches 1B views", min: -55, max: 55 },
    { reason: "Famous streamer mentions memecoin", min: -50, max: 50 },
    { reason: "Reddit community creates new meme trend", min: -45, max: 45 },
    { reason: "TikTok dance with memecoin goes viral", min: -40, max: 40 }
  ],
  ru: [
    { reason: "Новый мем с Бо Сином стал вирусным", min: -60, max: 60 },
    { reason: "Мем с Доге набрал 1 млрд просмотров", min: -55, max: 55 },
    { reason: "Известный стример упомянул мемкоин", min: -50, max: 50 },
    { reason: "Сообщество Reddit создает новый мем-тренд", min: -45, max: 45 },
    { reason: "Танец с мемкоином стал вирусным в TikTok", min: -40, max: 40 }
  ]
};

const moneyEvents = {
  en: [
    { reason: "Found a $50 bill on the street!", amount: 50, animation: "bounce" },
    { reason: "Found a $100 bill on the street!", amount: 100, animation: "bounce" },
    { reason: "Your distant relative from Congo sent you some money!", min: 15, max: 100, animation: "slide" },
    { reason: "Won a small lottery prize!", min: 15, max: 100, animation: "rotate" },
    { reason: "Found money in an old jacket!", min: 15, max: 100, animation: "fade" },
    { reason: "Street musician tips!", min: 15, max: 100, animation: "scale" }
  ],
  ru: [
    { reason: "Нашли 50$ на улице!", amount: 50, animation: "bounce" },
    { reason: "Нашли 100$ на улице!", amount: 100, animation: "bounce" },
    { reason: "Дальний родственник из Конго прислал вам деньги!", min: 15, max: 100, animation: "slide" },
    { reason: "Выиграли в лотерею!", min: 15, max: 100, animation: "rotate" },
    { reason: "Нашли деньги в старой куртке!", min: 15, max: 100, animation: "fade" },
    { reason: "Чаевые уличного музыканта!", min: 15, max: 100, animation: "scale" }
  ]
};

const createInitialPriceHistory = (basePrice: number) => {
  return Array(288).fill(0).map((_, i) => {
    const randomChange = 1 + (Math.random() * 0.002 - 0.001);
    const minPrice = basePrice < 0.1 ? 0.1 : basePrice * 0.1;
    return Math.max(basePrice * (1 + (i * 0.001)) * randomChange, minPrice);
  });
};

const initialCoins = [
  {
    id: 'bitcoin',
    name: 'Bitcoin',
    symbol: 'BTC',
    price: 30000,
    change24h: 2.5,
    isMeme: false,
    icon: '₿',
    marketCap: 580000000000,
    volume24h: 25000000000,
    priceHistory: createInitialPriceHistory(30000)
  },
  {
    id: 'ethereum',
    name: 'Ethereum',
    symbol: 'ETH',
    price: 2000,
    change24h: 1.8,
    isMeme: false,
    icon: 'Ξ',
    marketCap: 240000000000,
    volume24h: 15000000000,
    priceHistory: createInitialPriceHistory(2000)
  },
  {
    id: 'ripple',
    name: 'Ripple',
    symbol: 'XRP',
    price: 0.5,
    change24h: 1.2,
    isMeme: false,
    icon: 'X',
    marketCap: 25000000000,
    volume24h: 2000000000,
    priceHistory: createInitialPriceHistory(0.5)
  },
  {
    id: 'solana',
    name: 'Solana',
    symbol: 'SOL',
    price: 100,
    change24h: 3.0,
    isMeme: false,
    icon: 'S',
    marketCap: 40000000000,
    volume24h: 3000000000,
    priceHistory: createInitialPriceHistory(100)
  },
  {
    id: 'cardano',
    name: 'Cardano',
    symbol: 'ADA',
    price: 0.3,
    change24h: 1.5,
    isMeme: false,
    icon: 'A',
    marketCap: 10000000000,
    volume24h: 1000000000,
    priceHistory: createInitialPriceHistory(0.3)
  },
  {
    id: 'litecoin',
    name: 'Litecoin',
    symbol: 'LTC',
    price: 150,
    change24h: 2.0,
    isMeme: false,
    icon: 'Ł',
    marketCap: 11000000000,
    volume24h: 900000000,
    priceHistory: createInitialPriceHistory(150)
  },
  {
    id: 'dogecoin',
    name: 'Dogecoin',
    symbol: 'DOGE',
    price: 0.15,
    change24h: 4.0,
    isMeme: true,
    icon: 'Ð',
    marketCap: 13000000000,
    volume24h: 1200000000,
    priceHistory: createInitialPriceHistory(0.15)
  },
  {
    id: 'shiba-inu',
    name: 'Shiba Inu',
    symbol: 'SHIB',
    price: 0.12,
    change24h: 5.0,
    isMeme: true,
    icon: 'S',
    marketCap: 5000000000,
    volume24h: 500000000,
    priceHistory: createInitialPriceHistory(0.12)
  },
  {
    id: 'pepe',
    name: 'PEPE',
    symbol: 'PEPE',
    price: 0.11,
    change24h: 6.0,
    isMeme: true,
    icon: 'P',
    marketCap: 1000000000,
    volume24h: 100000000,
    priceHistory: createInitialPriceHistory(0.11)
  },
  {
    id: 'bonk',
    name: 'Bonk',
    symbol: 'BONK',
    price: 0.13,
    change24h: 4.5,
    isMeme: true,
    icon: 'B',
    marketCap: 600000000,
    volume24h: 60000000,
    priceHistory: createInitialPriceHistory(0.13)
  },
  {
    id: 'floki',
    name: 'Floki',
    symbol: 'FLOKI',
    price: 0.14,
    change24h: 3.8,
    isMeme: true,
    icon: 'F',
    marketCap: 400000000,
    volume24h: 40000000,
    priceHistory: createInitialPriceHistory(0.14)
  }
];

let cryptoEventTimer: NodeJS.Timeout | null = null;
let memeEventTimer: NodeJS.Timeout | null = null;
let moneyEventTimer: NodeJS.Timeout | null = null;
let eventResetTimer: NodeJS.Timeout | null = null;
let cryptoPriceTimer: NodeJS.Timeout | null = null;
let memePriceTimer: NodeJS.Timeout | null = null;

interface GameState {
  coins: Coin[];
  portfolio: Portfolio;
  quests: Quest[];
  lessons: LessonModule[];
  settings: Settings;
  currentEvent: { coin: string; change: number; reason: string; originalPrices: Record<string, number> } | null;
  moneyEvent: { amount: number; reason: string; animation: string } | null;
  updateCoinPrices: () => void;
  buyCoin: (coinId: string, amount: number) => void;
  sellCoin: (coinId: string, amount: number) => void;
  completeQuest: (questId: string) => void;
  completeLessonModule: (moduleId: string) => void;
  updateSettings: (settings: Partial<Settings>) => void;
  clearEvent: () => void;
  clearMoneyEvent: () => void;
}

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      coins: initialCoins,
      portfolio: {
        coins: [],
        balance: 10000,
      },
      quests: [
        {
          id: 'first-trade',
          title: 'First Trade',
          description: 'Make your first cryptocurrency trade',
          reward: 100,
          completed: false,
          requirements: {
            type: 'trade',
            target: 1,
            progress: 0,
          },
        },
        {
          id: 'crypto-master',
          title: 'Crypto Master',
          description: 'Complete all basic crypto lessons',
          reward: 500,
          completed: false,
          requirements: {
            type: 'learn',
            target: 3,
            progress: 0,
          },
        },
        {
          id: 'portfolio-diversity',
          title: 'Portfolio Diversity',
          description: 'Own at least 3 different cryptocurrencies',
          reward: 300,
          completed: false,
          requirements: {
            type: 'hold',
            target: 3,
            progress: 0,
          },
        },
      ],
      lessons: [
        {
          id: 'crypto-basics-1',
          title: 'Understanding Cryptocurrency',
          content: 'Learn about the fundamentals of cryptocurrency and blockchain technology.',
          completed: false,
          quiz: [
            {
              question: 'What is blockchain?',
              options: [
                'A type of cryptocurrency',
                'A distributed ledger technology',
                'A trading platform',
                'A digital wallet'
              ],
              correctAnswer: 1,
            },
          ],
        },
        {
          id: 'crypto-basics-2',
          title: 'Trading Basics',
          content: 'Learn how to analyze cryptocurrency markets and make informed trading decisions.',
          completed: false,
          quiz: [
            {
              question: 'What is market capitalization?',
              options: [
                'The total value of a cryptocurrency',
                'The price of one coin',
                'The number of trades per day',
                'The trading volume'
              ],
              correctAnswer: 0,
            },
          ],
        },
        {
          id: 'crypto-basics-3',
          title: 'Risk Management',
          content: 'Learn about managing risks in cryptocurrency trading.',
          completed: false,
          quiz: [
            {
              question: 'What is diversification?',
              options: [
                'Buying only one type of cryptocurrency',
                'Spreading investments across different assets',
                'Trading frequently',
                'Holding for long term'
              ],
              correctAnswer: 1,
            },
          ],
        },
      ],
      settings: {
        volume: 0.5,
        language: 'ru',
        version: '1.0.0'
      },
      currentEvent: null,
      moneyEvent: null,

      updateCoinPrices: () => {
        const state = get();
        
        // Clear existing timers
        if (cryptoPriceTimer) clearInterval(cryptoPriceTimer);
        if (memePriceTimer) clearInterval(memePriceTimer);
        
        // Update crypto prices every 30 seconds
        cryptoPriceTimer = setInterval(() => {
          const state = get();
          if (!state.currentEvent) {
            set((state) => ({
              coins: state.coins.map(coin => {
                if (!coin.isMeme) {
                  const priceChange = (Math.random() * 0.02) - 0.01; // 1-3% change
                  const minPrice = 0.01;
                  const newPrice = Math.max(coin.price * (1 + priceChange), minPrice);
                  const newPriceHistory = [...coin.priceHistory.slice(1), newPrice];
                  
                  return {
                    ...coin,
                    price: newPrice,
                    change24h: ((newPrice - coin.priceHistory[0]) / coin.priceHistory[0]) * 100,
                    priceHistory: newPriceHistory
                  };
                }
                return coin;
              })
            }));
          }
        }, 30000);

        // Update meme coin prices every 20 seconds
        memePriceTimer = setInterval(() => {
          const state = get();
          if (!state.currentEvent) {
            set((state) => ({
              coins: state.coins.map(coin => {
                if (coin.isMeme) {
                  const priceChange = (Math.random() * 0.04) - 0.02; // 2-6% change
                  const minPrice = 0.1;
                  const newPrice = Math.max(coin.price * (1 + priceChange), minPrice);
                  const newPriceHistory = [...coin.priceHistory.slice(1), newPrice];
                  
                  return {
                    ...coin,
                    price: newPrice,
                    change24h: ((newPrice - coin.priceHistory[0]) / coin.priceHistory[0]) * 100,
                    priceHistory: newPriceHistory
                  };
                }
                return coin;
              })
            }));
          }
        }, 20000);

        if (!cryptoEventTimer) {
          cryptoEventTimer = setInterval(() => {
            const state = get();
            const currentLanguage = state.settings.language as keyof typeof marketEvents;
            const events = marketEvents[currentLanguage] || marketEvents.en;
            const event = events[Math.floor(Math.random() * events.length)];
            const cryptoCoins = state.coins.filter(c => !c.isMeme);
            const randomCoin = cryptoCoins[Math.floor(Math.random() * cryptoCoins.length)];
            const change = event.min + Math.random() * (event.max - event.min);
            
            const originalPrices: Record<string, number> = {};
            state.coins.forEach(coin => {
              originalPrices[coin.id] = coin.price;
            });

            set((state) => ({
              currentEvent: {
                coin: randomCoin.name,
                change,
                reason: event.reason,
                originalPrices
              },
              coins: state.coins.map(coin => {
                if (coin.id === randomCoin.id) {
                  const minPrice = coin.isMeme ? 0.1 : 0.01;
                  const newPrice = Math.max(coin.price * (1 + change / 100), minPrice);
                  const newPriceHistory = [...coin.priceHistory.slice(1), newPrice];
                  return {
                    ...coin,
                    price: newPrice,
                    change24h: change,
                    priceHistory: newPriceHistory
                  };
                }
                return coin;
              })
            }));

            // Clear any existing reset timer
            if (eventResetTimer) {
              clearTimeout(eventResetTimer);
            }

            // Set up new reset timer for exactly 1 minute
            eventResetTimer = setTimeout(() => {
              const state = get();
              if (state.currentEvent) {
                set((state) => ({
                  coins: state.coins.map(coin => {
                    const originalPrice = state.currentEvent!.originalPrices[coin.id];
                    return {
                      ...coin,
                      price: originalPrice,
                      priceHistory: [...coin.priceHistory.slice(1), originalPrice]
                    };
                  }),
                  currentEvent: null
                }));
              }
            }, 60000); // 1 minute

            // Hide the event notification after 5 seconds
            setTimeout(() => {
              set((state) => ({
                ...state,
                currentEvent: {
                  ...state.currentEvent!,
                  reason: '' // Keep the event but hide the notification
                }
              }));
            }, 5000);

          }, 300000); // Every 5 minutes
        }

        if (!memeEventTimer) {
          memeEventTimer = setInterval(() => {
            const state = get();
            const currentLanguage = state.settings.language as keyof typeof memeEvents;
            const events = memeEvents[currentLanguage] || memeEvents.en;
            const event = events[Math.floor(Math.random() * events.length)];
            const memeCoins = state.coins.filter(c => c.isMeme);
            const randomCoin = memeCoins[Math.floor(Math.random() * memeCoins.length)];
            const change = event.min + Math.random() * (event.max - event.min);
            
            const originalPrices: Record<string, number> = {};
            state.coins.forEach(coin => {
              originalPrices[coin.id] = coin.price;
            });

            set((state) => ({
              currentEvent: {
                coin: randomCoin.name,
                change,
                reason: event.reason,
                originalPrices
              },
              coins: state.coins.map(coin => {
                if (coin.id === randomCoin.id) {
                  const minPrice = 0.1;
                  const newPrice = Math.max(coin.price * (1 + change / 100), minPrice);
                  const newPriceHistory = [...coin.priceHistory.slice(1), newPrice];
                  return {
                    ...coin,
                    price: newPrice,
                    change24h: change,
                    priceHistory: newPriceHistory
                  };
                }
                return coin;
              })
            }));

            // Clear any existing reset timer
            if (eventResetTimer) {
              clearTimeout(eventResetTimer);
            }

            // Set up new reset timer for exactly 1 minute
            eventResetTimer = setTimeout(() => {
              const state = get();
              if (state.currentEvent) {
                set((state) => ({
                  coins: state.coins.map(coin => {
                    const originalPrice = state.currentEvent!.originalPrices[coin.id];
                    return {
                      ...coin,
                      price: originalPrice,
                      priceHistory: [...coin.priceHistory.slice(1), originalPrice]
                    };
                  }),
                  currentEvent: null
                }));
              }
            }, 60000); // 1 minute

            // Hide the event notification after 5 seconds
            setTimeout(() => {
              set((state) => ({
                ...state,
                currentEvent: {
                  ...state.currentEvent!,
                  reason: '' // Keep the event but hide the notification
                }
              }));
            }, 5000);

          }, 180000); // Every 3 minutes
        }

        if (!moneyEventTimer) {
          moneyEventTimer = setInterval(() => {
            const state = get();
            const currentLanguage = state.settings.language as keyof typeof moneyEvents;
            const events = moneyEvents[currentLanguage] || moneyEvents.en;
            const event = events[Math.floor(Math.random() * events.length)];
            
            let amount: number;
            if ('amount' in event) {
              amount = event.amount;
            } else {
              amount = Math.floor(event.min + Math.random() * (event.max - event.min));
            }

            set((state) => ({
              moneyEvent: {
                amount,
                reason: event.reason,
                animation: event.animation
              },
              portfolio: {
                ...state.portfolio,
                balance: state.portfolio.balance + amount
              }
            }));

            setTimeout(() => {
              set((state) => ({
                moneyEvent: null
              }));
            }, 5000);

          }, 300000);
        }
      },

      clearEvent: () => {
        set({ currentEvent: null });
      },

      clearMoneyEvent: () => {
        set({ moneyEvent: null });
      },

      buyCoin: (coinId: string, amount: number) => {
        const state = get();
        const coin = state.coins.find(c => c.id === coinId);
        if (!coin) return;

        const cost = coin.price * amount;
        if (cost > state.portfolio.balance) return;

        const updatedQuests = state.quests.map(quest => {
          if (quest.requirements.type === 'trade' && !quest.completed) {
            const newProgress = Math.min(quest.requirements.progress + 1, quest.requirements.target);
            return {
              ...quest,
              requirements: {
                ...quest.requirements,
                progress: newProgress
              }
            };
          }
          return quest;
        });

        set((state) => {
          const existingPosition = state.portfolio.coins.find(c => c.coinId === coinId);
          const updatedCoins = existingPosition
            ? state.portfolio.coins.map(c => 
                c.coinId === coinId 
                  ? { 
                      ...c, 
                      amount: c.amount + amount,
                      averageBuyPrice: (c.averageBuyPrice * c.amount + cost) / (c.amount + amount)
                    }
                  : c
              )
            : [...state.portfolio.coins, { coinId, amount, averageBuyPrice: coin.price }];

          return {
            portfolio: {
              coins: updatedCoins,
              balance: state.portfolio.balance - cost
            },
            quests: updatedQuests
          };
        });
      },

      sellCoin: (coinId: string, amount: number) => {
        const state = get();
        const coin = state.coins.find(c => c.id === coinId);
        const position = state.portfolio.coins.find(c => c.coinId === coinId);
        
        if (!coin || !position || position.amount < amount) return;

        const revenue = coin.price * amount;

        set((state) => ({
          portfolio: {
            coins: state.portfolio.coins
              .map(c => 
                c.coinId === coinId 
                  ? { ...c, amount: c.amount - amount }
                  : c
              )
              .filter(c => c.amount > 0),
            balance: state.portfolio.balance + revenue
          }
        }));
      },

      completeQuest: (questId: string) => {
        const state = get();
        const quest = state.quests.find(q => q.id === questId);
        
        if (!quest || quest.completed || quest.requirements.progress < quest.requirements.target) {
          return;
        }

        set((state) => ({
          quests: state.quests.map(q =>
            q.id === questId
              ? { ...q, completed: true }
              : q
          ),
          portfolio: {
            ...state.portfolio,
            balance: state.portfolio.balance + quest.reward
          }
        }));
      },

      completeLessonModule: (moduleId: string) => {
        set((state) => {
          const updatedLessons = state.lessons.map(lesson =>
            lesson.id === moduleId ? { ...lesson, completed: true } : lesson
          );

          const completedLessons = updatedLessons.filter(lesson => lesson.completed).length;

          const updatedQuests = state.quests.map(quest => {
            if (quest.requirements.type === 'learn' && !quest.completed) {
              return {
                ...quest,
                requirements: {
                  ...quest.requirements,
                  progress: Math.min(completedLessons, quest.requirements.target)
                }
              };
            }
            return quest;
          });

          return {
            lessons: updatedLessons,
            quests: updatedQuests
          };
        });
      },

      updateSettings: (newSettings: Partial<Settings>) => {
        set((state) => ({
          settings: {
            ...state.settings,
            ...newSettings
          }
        }));
      }
    }),
    {
      name: 'crypto-game-storage'
    }
  )
);